<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RedirectResponse;

class DefaultController extends Controller
{
    /**
     * @Route("/", name="homepage")
     */
    public function indexAction(Request $request)
    {
        // replace this example code with whatever you need
        $authChecker = $this->container->get('security.authorization_checker');
        $router = $this->container->get('router');

        if($authChecker->isGranted('ROLE_ADMMIN')){
            return new RedirectResponse($router->generate('admin_home'), 307);
        }elseif ($authChecker->isGranted('ROLE_USER')){


            return $this->render('default/index.html.twig', [
                'base_dir' => realpath($this->getParameter('kernel.project_dir')).DIRECTORY_SEPARATOR,
                'user_name' => 'JERRY',
            ]);
        }else{
            //return new RedirectResponse($router->generate('login'), 307);
            return new RedirectResponse('/login', 307);
        }


    }
}
